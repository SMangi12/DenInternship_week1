//
//
//package com.example.internship_week1;
//
//import android.os.Bundle;
//import androidx.activity.ComponentActivity;
//import androidx.activity.compose.setContent;
//
//import com.example.internship_week1.jetUi.ResultScreenKt;
//
//public class FinalScoreActivity extends ComponentActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        String name = getIntent().getStringExtra("USERNAME");
//        int score = getIntent().getIntExtra("SCORE", 0); // default to 0
//        setContent(() -> {
//            ResultScreenKt.ResultScreen(name, score);
//            return null;
//        });
//    }
//}
