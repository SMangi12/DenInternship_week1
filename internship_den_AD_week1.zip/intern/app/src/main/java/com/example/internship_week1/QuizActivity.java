package com.example.internship_week1;
import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.activity.ComponentActivity;
import androidx.compose.ui.platform.ComposeView;
import com.example.internship_week1.jetUi.ComposeBridge;
import com.example.internship_week1.jetUi.FinalScoreActivity;
import com.example.internship_week1.jetUi.Question;
import com.example.internship_week1.jetUi.QuestionData;
import java.util.Collections;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
public class QuizActivity extends ComponentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String name = getIntent().getStringExtra("USERNAME");
        String topic = getIntent().getStringExtra("TOPIC");
        List<Question> questions;
        switch (topic) {
            case "Computer Networks":
                questions = QuestionData.INSTANCE.getComputerNetworksQuestions();
                break;
            case "Data Structures and Algorithms":
                questions = QuestionData.INSTANCE.getDsaQuestions();
                break;
            case "Android Development":
                questions = QuestionData.INSTANCE.getAndroidDevelopmentQuestions();
                break;
            default:
                questions = QuestionData.INSTANCE.getComputerNetworksQuestions();
        }
        Collections.shuffle(questions);
        List<Question> selectedQuestions = questions.subList(0, 5);
        ComposeView composeView = ComposeBridge.createComposeView(
                this,
                selectedQuestions,
                name,
                new Function1<Integer, Unit>() {
                    @Override
                    public Unit invoke(Integer score) {
                        Intent intent = new Intent(QuizActivity.this, FinalScoreActivity.class);
                        intent.putExtra("USERNAME", name);
                        intent.putExtra("SCORE", score);
                        startActivity(intent);
                        finish(); // optional
                        return Unit.INSTANCE;
                    }
                }
        );
        FrameLayout container = new FrameLayout(this);
        container.addView(composeView);
        setContentView(container);
    }
}