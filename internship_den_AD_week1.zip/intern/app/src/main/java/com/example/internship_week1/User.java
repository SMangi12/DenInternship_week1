//package com.example.internship_week1;
//
//public class User {
//    String name;
//    String password;
//    int total_quizzes_attempted;
//    int total_correct_questions;
//            String email;
//            int correct_questions_in_this_quiz;
//
//    public User(String name, String password, int total_quizzes_attempted, int total_correct_questions, String email, int correct_questions_in_this_quiz) {
//        this.name = name;
//        this.password = password;
//        this.total_quizzes_attempted = total_quizzes_attempted;
//        this.total_correct_questions = total_correct_questions;
//        this.email = email;
//        this.correct_questions_in_this_quiz = correct_questions_in_this_quiz;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }
//
//    public int getTotal_quizzes_attempted() {
//        return total_quizzes_attempted;
//    }
//
//    public void setTotal_quizzes_attempted(int total_quizzes_attempted) {
//        this.total_quizzes_attempted = total_quizzes_attempted;
//    }
//
//    public int getTotal_correct_questions() {
//        return total_correct_questions;
//    }
//
//    public void setTotal_correct_questions(int total_correct_questions) {
//        this.total_correct_questions = total_correct_questions;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public int getCorrect_questions_in_this_quiz() {
//        return correct_questions_in_this_quiz;
//    }
//
//    public void setCorrect_questions_in_this_quiz(int correct_questions_in_this_quiz) {
//        this.correct_questions_in_this_quiz = correct_questions_in_this_quiz;
//    }
//
//
//    @Override
//    public   String toString(){
//         return name + " registered with us by the email: " + email + " has attempted total: " + total_quizzes_attempted + " quizzes and correctly answered: " + total_correct_questions + " questions /n Your total collective score for all quizzes is " + total_correct_questions;
//    }
//}
