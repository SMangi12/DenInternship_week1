package com.example.internship_week1.jetUi
import ResultScreen
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.internship_week1.MainActivity
class FinalScoreActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val name = intent.getStringExtra("USERNAME") ?: "User"
        val score = intent.getIntExtra("SCORE", 0)

        setContent {
            ResultScreen(
                username = name,
                score = score,
                onRetry = {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish() // optional: so user can't go back to score screen
                } ,
                onEnd = {
                  finishAffinity()

                }
            )
        }
    }
}
