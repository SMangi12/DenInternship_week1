package com.example.internship_week1;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.internship_week1.jetUi.ComposeLauncher;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ComposeLauncher.Companion.launch(this);
        finish();
    }
}